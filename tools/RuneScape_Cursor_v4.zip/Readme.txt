
==========
||Readme||
==========

RuneScape Cursors - By Doobie aka Joel

~

Hello, you have just downloaded RuneScape Cursors, Most cursors are animated, so the file
will be called .ani, But dont worry, Mouse pointer options accept .cur/.ani cursors only, 
and these cursors have the requirements.

- Putting the cursor on.

If you're having trouble, do not double click the santa hat, etc. Go to these following
paths..

> Control Panel
> Appearances & Themes

| On the top left corner it will say "Mouse Pointers" - Click it!

> Now go to Pointers
> Browse..

Find the cursor you want, And you done, cool, stylish cursors..

~ By Doobie aka Joel

� Copyright RuneScape Cursors 2006. | Doobie | JoeL |